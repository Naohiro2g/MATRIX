# OttoRemote

Piece Designs and other Additional Files - Includes the 3D design pieces supplied by Otto.strikingly.com.
Included in that directory is the Leg File that I designed and other documentation from their own website.

Otto_Arduino - Is the Arduino app that we created that uses the Bluetooth as a controller.

OTTO_smooth_criminal - Is an Arduino app created by somebody else that allows Otto to just dance.

The rest of the files is the actual Bluetooth app that works with BLUNO microcontrollers.
