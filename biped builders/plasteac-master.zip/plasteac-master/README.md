# plasteac
A 3D-printed robotic dancing teapot

Refer to each subproject for license information.

Read my blog articles for more information:

https://chapelierfou.org/2017/04/plasteac-a-dancing-teapot/

https://chapelierfou.org/2017/04/plasteac-enhancements/

https://vimeo.com/214493309

![Plasteac](https://chapelierfou.org/wp-content/uploads/2017/04/IMG_20170417_194630-825x510.jpg)

