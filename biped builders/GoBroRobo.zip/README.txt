                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2222780
GoBroRobo by jollyGreenGiant is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary


These were Christmas gifts in various permutations. Finally getting around to making one for myself. Gotten into the 3DLabPrint planes. Those are awesome. 

Added arms to the base OTTO DIY design, use the latest Otto feet, legs, head, etc for yours. These are just accessories if you will.

Built a base and top display and storage case for it. The head just barely fits over the robots head. You can lock it into place with the eye accessory. I created a bunch of cutouts on some prints. 

I made Otto run off an IR remote ( Tolako IR remote kit -https://www.amazon.com/gp/product/B01EL7I5HC/ ), created cases for the remote and embossed names into them.

Created a male and a female version of the torso with arms, I'm not sharing those for now, sorry.

I revised the calibration and IR driven smooth criminal code to work with arms as well. 

Printing them in PLA on a FFCP2016 directly on a glass bed. 

The calibration is HIGHLY recommended. You run the calibration from the serial window like a command line, adjust each appendage with +- Enter commands until it's exactly where you want everything, then back to the main menu, type save and it's saved to EEPROM. Flash the other code back and it will read and use the calibration settings you just set.