# Bobwi

<b>Warning: This is a prototype, some parts need to be improved.</B>

Robot, inspired by Bob and Zowi, if you want more information regarding Zowi, please visit:
www.bq.com/zowi
http://diwo.bq.com/en/zowi-cc-by-sa/


If you want to replicate this dance:  https://youtu.be/4x4xa3OTv4A

First you need to calibrate the servos:
https://github.com/G4lile0/Bobwi/tree/master/code/v1/arduino/v1/calibration

Then use that values, to load the Dance code.
https://github.com/G4lile0/Bobwi/tree/master/code/v1/arduino/v1/smooth_criminal

If you want to control the robot from your Android phone: 

Download the official "Zowi App" from bq

Configure the bluetooth module using this code:
https://github.com/G4lile0/Bobwi/tree/master/code/v2/arduino/code/hc06_bt_config

Then load the Zowi base v2 software:
https://github.com/G4lile0/Bobwi/tree/master/code/v2/arduino/code/ZOWI_BASE_v2


##License

<img src="./images/by-sa.png" width="200" align = "center">

All these products are released under [Creative Commons Attribution-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-sa/4.0/).

Todos estos productos están liberados mediante [Creative Commons Attribution-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-sa/4.0/).
