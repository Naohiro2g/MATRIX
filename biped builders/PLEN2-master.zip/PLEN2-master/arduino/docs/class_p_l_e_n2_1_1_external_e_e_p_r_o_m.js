var class_p_l_e_n2_1_1_external_e_e_p_r_o_m =
[
    [ "CHUNK_SIZE", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#a8aebdbedd670c2ae9b83c5efb0f316eaa3b6c8317e8268a5fb896923c4a8433d2", null ],
    [ "SLOT_SIZE", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#a384e612e5373158f853e5e7efb2dc679aa893a7791ec868480f4576b02e8a3c98", null ],
    [ "SLOT_BEGIN", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#a1d9154051d9835a3a062605770ebbac2a6391779cbbc4ba84b717ccfbd6a00fd4", null ],
    [ "SLOT_END", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#adf55bead9b5cbfa994d855a89b61fc0faada4fde0f7a073c7708de50f32336a33", null ],
    [ "ExternalEEPROM", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#a6de9ba73e5c1c5e68eeca23939cd19f0", null ],
    [ "begin", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#ab2fbe055be630b7a150120a1b0d78741", null ],
    [ "readSlot", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#aa427fcc2ddee1e2defc5d010f8277201", null ],
    [ "writeSlot", "class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#a99d218ed84e338400dbd857b2c95a9bc", null ]
];