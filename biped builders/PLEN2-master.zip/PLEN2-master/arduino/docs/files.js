var files =
[
    [ "AccelerationGyroSensor.h", "_acceleration_gyro_sensor_8h.html", "_acceleration_gyro_sensor_8h" ],
    [ "BuildConfig.h", "_build_config_8h.html", "_build_config_8h" ],
    [ "ExternalEEPROM.h", "_external_e_e_p_r_o_m_8h.html", "_external_e_e_p_r_o_m_8h" ],
    [ "firmware.h", "firmware_8h.html", null ],
    [ "Interpreter.h", "_interpreter_8h.html", "_interpreter_8h" ],
    [ "JointController.h", "_joint_controller_8h.html", "_joint_controller_8h" ],
    [ "Motion.h", "_motion_8h.html", "_motion_8h" ],
    [ "MotionController.h", "_motion_controller_8h.html", "_motion_controller_8h" ],
    [ "Parser.h", "_parser_8h.html", "_parser_8h" ],
    [ "Pin.h", "_pin_8h.html", "_pin_8h" ],
    [ "Profiler.h", "_profiler_8h.html", "_profiler_8h" ],
    [ "Protocol.h", "_protocol_8h.html", "_protocol_8h" ],
    [ "Soul.h", "_soul_8h.html", "_soul_8h" ],
    [ "System.h", "_system_8h.html", "_system_8h" ]
];