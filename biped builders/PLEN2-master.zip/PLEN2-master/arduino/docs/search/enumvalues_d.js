var searchData=
[
  ['update_5finterval_5fms',['UPDATE_INTERVAL_MS',['../class_p_l_e_n2_1_1_motion_1_1_frame.html#a8f32649e6ff9fab7577faffdd4dd5180a8af3f86dd6ba286a3c30b6f102e302e1',1,'PLEN2::Motion::Frame']]]
];
