var searchData=
[
  ['chunk_5fsize',['CHUNK_SIZE',['../class_p_l_e_n2_1_1_external_e_e_p_r_o_m.html#a8aebdbedd670c2ae9b83c5efb0f316eaa3b6c8317e8268a5fb896923c4a8433d2',1,'PLEN2::ExternalEEPROM']]],
  ['command_5fincoming',['COMMAND_INCOMING',['../class_p_l_e_n2_1_1_protocol.html#a8b28d846c454333a02272314f9a65b37a1782505a89917d473a6f934bbf0f9978',1,'PLEN2::Protocol']]]
];
