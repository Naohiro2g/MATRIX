var searchData=
[
  ['transition_5ftime_5fms',['transition_time_ms',['../class_p_l_e_n2_1_1_motion_1_1_frame.html#ac967f74e67c36a84f2754650e61c8d5a',1,'PLEN2::Motion::Frame']]]
];
