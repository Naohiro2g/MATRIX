var searchData=
[
  ['target_5fdeveloper_5fedition',['TARGET_DEVELOPER_EDITION',['../_build_config_8h.html#a59c0eef4710517eabb247d95dfdd7824',1,'BuildConfig.h']]],
  ['target_5fmirror_5fedition',['TARGET_MIRROR_EDITION',['../_build_config_8h.html#a227d72f33f9d51ed3b8d31c61a699993',1,'BuildConfig.h']]],
  ['target_5fplen14',['TARGET_PLEN14',['../_build_config_8h.html#ae0302360d2cd539f570f5f414ac39036',1,'BuildConfig.h']]],
  ['target_5fplen20',['TARGET_PLEN20',['../_build_config_8h.html#abfa5c5fa274caa5f5539ee9afaa7f0f0',1,'BuildConfig.h']]]
];
