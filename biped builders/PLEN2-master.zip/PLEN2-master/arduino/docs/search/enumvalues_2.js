var searchData=
[
  ['frame_5fbegin',['FRAME_BEGIN',['../class_p_l_e_n2_1_1_motion_1_1_frame.html#a8f32649e6ff9fab7577faffdd4dd5180a627da90111ae501ec29ce273f1f0c711',1,'PLEN2::Motion::Frame']]],
  ['frame_5fend',['FRAME_END',['../class_p_l_e_n2_1_1_motion_1_1_frame.html#a8f32649e6ff9fab7577faffdd4dd5180a7b134ae0dc9f5eddac5ed85e47860651',1,'PLEN2::Motion::Frame']]],
  ['framelength_5fmax',['FRAMELENGTH_MAX',['../class_p_l_e_n2_1_1_motion_1_1_header.html#a29157b3034dac4a2da9225f398f3e75da165efbb89715549de6047c12ce7b29e5',1,'PLEN2::Motion::Header']]],
  ['framelength_5fmin',['FRAMELENGTH_MIN',['../class_p_l_e_n2_1_1_motion_1_1_header.html#a29157b3034dac4a2da9225f398f3e75dac96732018d954f07f06f74646b602092',1,'PLEN2::Motion::Header']]]
];
