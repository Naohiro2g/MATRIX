var indexSectionsWithContent =
{
  0: "abcdefghijlmnopqrstuw~",
  1: "abcefhijmnps",
  2: "pu",
  3: "abefijmps",
  4: "abcdefghijlmnoprstuw~",
  5: "dfijlmnpstu",
  6: "bjs",
  7: "acfhijlmnpqrsu",
  8: "fptu",
  9: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

