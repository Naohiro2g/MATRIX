var _build_config_8h =
[
    [ "PLEN2_BUILD_CONFIG_H", "_build_config_8h.html#acfe855788e934cd39671e2302f6549d2", null ],
    [ "TARGET_DEVELOPER_EDITION", "_build_config_8h.html#a59c0eef4710517eabb247d95dfdd7824", null ],
    [ "TARGET_MIRROR_EDITION", "_build_config_8h.html#a227d72f33f9d51ed3b8d31c61a699993", null ],
    [ "TARGET_PLEN14", "_build_config_8h.html#ae0302360d2cd539f570f5f414ac39036", null ],
    [ "TARGET_PLEN20", "_build_config_8h.html#abfa5c5fa274caa5f5539ee9afaa7f0f0", null ]
];