var class_p_l_e_n2_1_1_motion_1_1_header =
[
    [ "NAME_LENGTH", "class_p_l_e_n2_1_1_motion_1_1_header.html#a29157b3034dac4a2da9225f398f3e75da73fc5161bac42becc7356064104a50f8", null ],
    [ "FRAMELENGTH_MIN", "class_p_l_e_n2_1_1_motion_1_1_header.html#a29157b3034dac4a2da9225f398f3e75dac96732018d954f07f06f74646b602092", null ],
    [ "FRAMELENGTH_MAX", "class_p_l_e_n2_1_1_motion_1_1_header.html#a29157b3034dac4a2da9225f398f3e75da165efbb89715549de6047c12ce7b29e5", null ],
    [ "get", "class_p_l_e_n2_1_1_motion_1_1_header.html#a7ab9acb8c1dc7895e45bf8399bb96e3b", null ],
    [ "init", "class_p_l_e_n2_1_1_motion_1_1_header.html#a9e57d30d7f9d76d21b1dca355ee5b408", null ],
    [ "set", "class_p_l_e_n2_1_1_motion_1_1_header.html#a64b564c7c256d2cfe566f0f362195e51", null ],
    [ "frame_length", "class_p_l_e_n2_1_1_motion_1_1_header.html#a6f7b1c960c3030f1080d6acae16b9b86", null ],
    [ "jump_slot", "class_p_l_e_n2_1_1_motion_1_1_header.html#a42c0f1dfc2c5cf046885e05ee0f9a593", null ],
    [ "loop_begin", "class_p_l_e_n2_1_1_motion_1_1_header.html#a2c5865a7eccca775e1c1d8a661149fe1", null ],
    [ "loop_count", "class_p_l_e_n2_1_1_motion_1_1_header.html#a4bf7327484f30e12448896e80d12f983", null ],
    [ "loop_end", "class_p_l_e_n2_1_1_motion_1_1_header.html#a52b813f751d4c9da65854ae025ec2cf6", null ],
    [ "name", "class_p_l_e_n2_1_1_motion_1_1_header.html#a1461e30416ae417ddecf6e35a9d175e6", null ],
    [ "NON_RESERVED", "class_p_l_e_n2_1_1_motion_1_1_header.html#af70127bff9958596c635098aa616cfd3", null ],
    [ "slot", "class_p_l_e_n2_1_1_motion_1_1_header.html#a9fc527d7f92657812e1b6d3c538dca1e", null ],
    [ "stop_flags", "class_p_l_e_n2_1_1_motion_1_1_header.html#a744697027a5de1996dadf513e2d23221", null ],
    [ "use_extra", "class_p_l_e_n2_1_1_motion_1_1_header.html#a7fe19c1566f231b0c473b4181cc1b119", null ],
    [ "use_jump", "class_p_l_e_n2_1_1_motion_1_1_header.html#aa6d2294e36af441fe464aeb082462e15", null ],
    [ "use_loop", "class_p_l_e_n2_1_1_motion_1_1_header.html#a48b0ee4d074038fbb84a4cdba4262a33", null ]
];